from django.db import models

# Create your models here.
class Registration(models.Model):
    First_Name = models.CharField(max_length=30)
    Last_Name = models.CharField(max_length=30)
    Date_of_birth = models.DateField()  
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    Roll_No = models.IntegerField(max_length=10)
    Father_Name = models.CharField(max_length=50)
    Mother_Name = models.CharField(max_length=50)
    

